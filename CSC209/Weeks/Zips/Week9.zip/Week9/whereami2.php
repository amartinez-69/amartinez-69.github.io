<!DOCTYPE hmtl>
<html>
<head>

<?php include "myLib.php"; ?>
</head>
<body>

<?php echo "this is work for Week " . extractFolderNumber($path); ?>
</body>
</html>