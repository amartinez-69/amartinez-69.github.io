<!DOCTYPE html>
<html>
<body>

<?php
$txt = "W3Schools.com";
echo "I love $txt!";
?>
<br>
<?php
$x = 5;
$y = 4;
echo $x + $y;
?>

</body>
</html>