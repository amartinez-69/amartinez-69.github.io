<html>
<link id="pagestyle" rel="stylesheet" href="../css/css.css">
<body>



<div class="main" >
    <h2>Welcome Admin!</h2>
    <div id="users" style="display: none;">
        <button type="button" onclick="loadDoc()" style="width: auto;">Update</button>
        <div id="demo"></div>
    </div>
</div>
<div class="sidenav">
    <h2 style="color: white; padding: 6px 8px 6px 16px;">Contents</h2>
    <a onclick="showUsers()">Users</a>
</div>

<script src="../js/js.js">
</script>


</body>
</html>