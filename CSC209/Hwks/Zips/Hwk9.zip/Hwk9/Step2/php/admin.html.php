<html>
<link id="pagestyle" rel="stylesheet" href="../css/css.css">
<body>


<button type="button" onclick="loadDoc()" style="width: auto;">Update</button>
<div id="demo">
</div>

<script src="../js/js.js"></script>


</body>
</html>