let ROW = "Sample text, CHECKCROSSBASIC, CHECKCROSSPRO";
//window.alert(ROW);
let newROW = ROW.replace("CHECKCROSSBASIC", "fa-check");
let newROW2 = newROW.replace("CHECKCROSSPRO", "fa-remove");
//window.alert(newROW2);
function addRow(rowInfo){ //unfinished, need to add e desired options to be placed on a row in the BASIC and PRO columns
  let newRow = rowInfo.split(",");
  const table = document.getElementById("table");
  console.log(table);
  let row = table.insertRow(-1);
  let cell1 = row.insertCell(0); 
  let cell2 = row.insertCell(1);
  let cell3 = row.insertCell(2);
  cell1.innerHTML = newRow[0];
  cell2.innerHTML = newRow[1];
  cell3.innerHTML = newRow[2];
}
addRow(newROW2);